package com.example.caboconsultas.io.response

class SimpleResponse {
}