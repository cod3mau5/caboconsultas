package com.example.caboconsultas.model

data class Schedule (val morning: ArrayList<HourInterval>, val afternoon: ArrayList<HourInterval>)